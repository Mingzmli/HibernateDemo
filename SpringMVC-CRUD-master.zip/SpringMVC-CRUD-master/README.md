SpringMVC-CRUD
==============

Spring MVC - Hibernate , Implementation CRUD(Create Read Update Delete)

menggunakan :
  Spring 3
  Hibernate 3
  JUnit
