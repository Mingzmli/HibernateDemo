Hibernate annotations for one to many relationship  
